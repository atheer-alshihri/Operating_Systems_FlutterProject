package com.example.guess_the_flag

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
